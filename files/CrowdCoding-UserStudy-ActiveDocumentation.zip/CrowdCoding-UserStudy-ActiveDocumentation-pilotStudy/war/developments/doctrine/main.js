var doctrine = require('doctrine');

console.log(doctrine);