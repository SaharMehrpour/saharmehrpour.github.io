
var estraverse = global.estraverse = require('estraverse');
var escodegen = global.escodegen = require('escodegen');
var esprima = global.esprima = require('esprima');
var escope = global.escope = require('escope');
estraverse.browser = true;
esprima.browser = true;
escope.browser = true;