package com.crowdcoding.dto.ajax.microtask.submission;

import com.crowdcoding.dto.DTO;


public class ChallengeReviewDTO extends DTO
{
	public Boolean  isChallengeWon;

	public ChallengeReviewDTO() {}
}