package com.crowdcoding.dto.ajax.microtask.submission;

import com.crowdcoding.dto.DTO;


public class ReviewDTO extends DTO
{
	public String reviewText;
	public int qualityScore;
	public boolean  fromDisputedMicrotask;

	public ReviewDTO() {}
}