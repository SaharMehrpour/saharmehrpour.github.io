package com.crowdcoding.dto;

public class ChallengeDTO extends DTO
{

	public String challengeText;

	// Default constructor (required by Jackson JSON library)
	public ChallengeDTO()
	{
	}

}
