# Active Documentation

This app is written in "React" framework.
It communicates with the server using "Web-Socket".